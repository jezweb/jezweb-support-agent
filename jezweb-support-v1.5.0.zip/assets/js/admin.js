/**
 * Jezweb Support Agent - Admin JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Placeholder for future admin functionality
        console.log('Jezweb Support Agent loaded');

        // Could add:
        // - Test API endpoint buttons
        // - Live preview of site knowledge
        // - Connection status indicator
    });

})(jQuery);
